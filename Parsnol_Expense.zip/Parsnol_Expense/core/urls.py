from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_user, name='register'),
    path('login/', views.login_user, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('', views.dashboard, name='dashboard'),
    path('delete/<int:pk>/', views.delete_expense, name='delete_expense'),
    path('export/csv/', views.export_expenses_csv, name='export_csv'),
]
