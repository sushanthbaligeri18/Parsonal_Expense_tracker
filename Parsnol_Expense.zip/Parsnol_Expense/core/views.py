from django.shortcuts import render, redirect, get_object_or_404
from .models import AppUser, Expense, Income
from django.contrib import messages

def get_current_user(request):
    user_id = request.session.get('user_id')
    if user_id:
        return AppUser.objects.filter(id=user_id).first()
    return None

def register_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        phone_no = request.POST.get('phone_no')
        password_raw = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        if password_raw != confirm_password:
            messages.error(request, 'Passwords do not match!')
            return redirect('register')
            
        if AppUser.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists!')
            return redirect('register')
            
        if AppUser.objects.filter(phone_no=phone_no).exists():
            messages.error(request, 'Phone number already registered!')
            return redirect('register')
        
        user = AppUser(username=username, phone_no=phone_no)
        user.set_password(password_raw)
        user.save()
        messages.success(request, 'Registration successful, please login.')
        return redirect('login')
        
    return render(request, 'register.html')

def login_user(request):
    if request.method == 'POST':
        phone_no = request.POST.get('phone_no')
        password_raw = request.POST.get('password')
        
        user = AppUser.objects.filter(phone_no=phone_no).first()
        if user and user.check_password(password_raw):
            request.session['user_id'] = user.id
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid phone number or password.')
            return redirect('login')
            
    return render(request, 'login.html')

def logout_user(request):
    request.session.flush()
    return redirect('login')

import csv
from datetime import date, timedelta
from django.db.models import Sum

def dashboard(request):
    user = get_current_user(request)
    if not user:
        return redirect('login')
        
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'add_income':
            amount = request.POST.get('income_amount')
            date_val = request.POST.get('income_date')
            if amount and date_val:
                Income.objects.create(user=user, amount=amount, date=date_val)
                messages.success(request, 'Income added successfully.')
                return redirect('dashboard')
                
        else:
            title = request.POST.get('title')
            amount = request.POST.get('amount')
            date_val = request.POST.get('date')
            
            if title and amount and date_val:
                amount_f = float(amount)
                from django.db.models import Sum
                total_income = Income.objects.filter(user=user, date=date_val).aggregate(Sum('amount'))['amount__sum'] or 0
                total_expense = Expense.objects.filter(user=user, date=date_val).aggregate(Sum('amount'))['amount__sum'] or 0
                
                if (float(total_expense) + amount_f) > float(total_income):
                    messages.warning(request, f'Warning: Total expense exceeds recorded income for {date_val}!')
                
                Expense.objects.create(user=user, title=title, amount=amount, date=date_val)
                messages.success(request, 'Expense added successfully.')
                return redirect('dashboard')
            
    expenses = Expense.objects.filter(user=user).order_by('-date')
    
    # Filter Logic for Sum only
    filter_param = request.GET.get('filter', 'all')
    today = date.today()
    
    filtered_expenses = expenses
    if filter_param == 'today':
        filtered_expenses = expenses.filter(date=today)
    elif filter_param == 'week':
        start_date = today - timedelta(days=today.weekday())
        filtered_expenses = expenses.filter(date__gte=start_date, date__lte=today + timedelta(days=6-today.weekday()))
    elif filter_param == 'month':
        start_date = today.replace(day=1)
        next_month = start_date.replace(month=start_date.month % 12 + 1, day=1) if start_date.month < 12 else start_date.replace(year=start_date.year + 1, month=1, day=1)
        filtered_expenses = expenses.filter(date__gte=start_date, date__lt=next_month)
    elif filter_param == 'year':
        start_date = today.replace(month=1, day=1)
        next_year = start_date.replace(year=start_date.year + 1)
        filtered_expenses = expenses.filter(date__gte=start_date, date__lt=next_year)
    
    total = sum(e.amount for e in filtered_expenses)
    
    # Calculate Today's Income
    from django.db.models import Sum
    todays_income = Income.objects.filter(user=user, date=today).aggregate(Sum('amount'))['amount__sum'] or 0
    
    # Group for chart
    import json
    grouped_expenses = filtered_expenses.values('title').annotate(total_amount=Sum('amount')).order_by('title')
    chart_labels = json.dumps([str(item['title']) for item in grouped_expenses])
    chart_data = json.dumps([float(item['total_amount']) for item in grouped_expenses])
    
    context = {
        'user': user,
        'expenses': filtered_expenses,
        'total': total,
        'current_filter': filter_param,
        'chart_labels': chart_labels,
        'chart_data': chart_data,
        'todays_income': todays_income,
    }
    return render(request, 'dashboard.html', context)

def delete_expense(request, pk):
    user = get_current_user(request)
    if not user:
        return redirect('login')
        
    expense = get_object_or_404(Expense, id=pk, user=user)
    if request.method == 'POST':
        expense.delete()
        messages.success(request, 'Expense deleted successfully.')
    return redirect('dashboard')

import csv
from django.http import HttpResponse

def export_expenses_csv(request):
    user = get_current_user(request)
    if not user:
        return redirect('login')
        
    expenses = Expense.objects.filter(user=user).order_by('-date')
    
    # Matching Filter Logic for CSV
    filter_param = request.GET.get('filter', 'all')
    today = date.today()
    if filter_param == 'today':
        expenses = expenses.filter(date=today)
    elif filter_param == 'week':
        start_date = today - timedelta(days=today.weekday())
        expenses = expenses.filter(date__gte=start_date, date__lte=today + timedelta(days=6-today.weekday()))
    elif filter_param == 'month':
        start_date = today.replace(day=1)
        next_month = start_date.replace(month=start_date.month % 12 + 1, day=1) if start_date.month < 12 else start_date.replace(year=start_date.year + 1, month=1, day=1)
        expenses = expenses.filter(date__gte=start_date, date__lt=next_month)
    elif filter_param == 'year':
        start_date = today.replace(month=1, day=1)
        next_year = start_date.replace(year=start_date.year + 1)
        expenses = expenses.filter(date__gte=start_date, date__lt=next_year)
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="expenses_{filter_param}.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Date', 'Title', 'Amount'])
    
    for expense in expenses:
        writer.writerow([expense.date.strftime("%Y-%m-%d"), expense.title, expense.amount])
        
    return response
